//
//  �PROJECTNAMEASIDENTIFIER�_Filesystem.h
//  �PROJECTNAME�
//
//  Created by �FULLUSERNAME� on �DATE�.
//  Copyright �YEAR� �ORGANIZATIONNAME�. All rights reserved.
//
// Filesystem operations.
//
#import <Foundation/Foundation.h>

// The core set of file system operations. This class will serve as the delegate
// for GMUserFileSystemFilesystem. For more details, see the section on 
// GMUserFileSystemOperations found in the documentation at:
// http://macfuse.googlecode.com/svn/trunk/core/sdk-objc/Documentation/index.html
@interface �PROJECTNAMEASIDENTIFIER�_Filesystem : NSObject  {
}

@end
