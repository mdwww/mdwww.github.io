//
//  �PROJECTNAMEASIDENTIFIER�_Controller.h
//  �PROJECTNAME�
//
//  Created by �FULLUSERNAME� on �DATE�.
//  Copyright �YEAR� �ORGANIZATIONNAME�. All rights reserved.
//
#import <Cocoa/Cocoa.h>

@class GMUserFileSystem;
@class �PROJECTNAMEASIDENTIFIER�_Controller;

@interface �PROJECTNAMEASIDENTIFIER�_Controller : NSObject {
  GMUserFileSystem* fs_;
  �PROJECTNAMEASIDENTIFIER�_Controller* fs_delegate_;
}

@end
