/*
 * MacFUSE libosxfuse_i32/libosxfuse_i64 adapter 
 *
 * Copyright (c) 2011-2012 Benjamin Fleischer
 */

#include <stdbool.h>

const char *macfuse_version(void);
